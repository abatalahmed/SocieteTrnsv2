/**
 * 
 */
/**
 * 
 */
module tpSocieteTransport {
	requires java.desktop;
}